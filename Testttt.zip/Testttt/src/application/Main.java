package application;
	

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.BlendMode;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;


public class Main extends Application {
	private static Stage window;
	private static Scene scene1;
	private static Scene scene2;
	private static Scene scene3;
	private static Scene scene4;
	private static Scene scene5;
	private static Scene scene6;
	private static Scene scene7;
	private static Scene scene8;
	
	RadioButton radio1;
	RadioButton radio2;
	
	@Override
	public void start(Stage primaryStage) {
		window=primaryStage;
		try {
			Image image = new Image(new FileInputStream(
					"C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 1\\Burger 1(without bg)2.png"));
			
			window.setTitle("PAK KARIM HAMBURGER STORE");
			window.getIcons().add(image);
			window.setScene(FirstInterface());
			window.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public Scene FirstInterface() {
		try {
			
			BackgroundImage myBI = new BackgroundImage(
					new Image(new FileInputStream(
							"C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 1\\Background.jpg")),
					BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT,
					BackgroundSize.DEFAULT);
			
			Image image = new Image(new FileInputStream(
					"C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 1\\Burger 1(without bg)2.png"));
			
			BorderPane bPane = new BorderPane();
			
			ImageView logoKedai = new ImageView(image);
			logoKedai.setFitWidth(200);
			logoKedai.setFitHeight(150);

			radio1 = new RadioButton("Yes");
			radio2 = new RadioButton("No");
			ToggleGroup radioGroup = new ToggleGroup();
			
			radio1.setToggleGroup(radioGroup);
			radio2.setToggleGroup(radioGroup);
			
			//button
			Button button = new Button("Start Order");
			button.setMaxWidth(250);
			
			
			Label label2 = new Label("Member Validity:");			
		
			Label label4 = new Label("Welcome");
			label4.setStyle("-fx-font-size: 20; -fx-font-weight: bold");

			TextField name = new TextField();
			TextField noId = new TextField();
			Label labelresponse = new Label("Error. Your name or ID have not been entered.");
			labelresponse.setStyle("-fx-font-weight: bold; -fx-text-fill: red ; -fx-font-size: 15");
			

			GridPane pane = new GridPane();
			GridPane.setHalignment(button, HPos.CENTER);
			pane.setAlignment(Pos.CENTER);
			pane.setHgap(40);
			pane.setVgap(20);
			
			//Logo and welcome
			VBox LogoWelcome = new VBox(20);
			LogoWelcome.setAlignment(Pos.CENTER);
			LogoWelcome.getChildren().addAll(logoKedai,label4);
			bPane.setTop(LogoWelcome);

			//Info : name,member validity and member id
			name.setPromptText("Username");
			GridPane.setConstraints(name,0,1);
			pane.getChildren().add(name);
			
			
			HBox radioButton = new HBox(10,radio1,radio2);
			
			pane.add(label2, 0, 2);
			pane.add(radioButton, 0, 3);
			
			noId.setPromptText("Member ID");
			GridPane.setConstraints(noId,0,4);
			pane.getChildren().add(noId);
						
			pane.add(button, 0, 7);
			pane.add(labelresponse, 0, 8);
			
			pane.getChildren().get(3).setVisible(false);
			pane.getChildren().get(5).setVisible(false);
			
			//shadow
			DropShadow shadow = new DropShadow();
			shadow.setRadius(30);
			shadow.setColor(Color.DARKGREY);;
			
			
			//Box
			VBox infoBox = new VBox();
			infoBox.setAlignment(Pos.CENTER);
			infoBox.getChildren().addAll(pane);
			infoBox.setMaxSize(400, 50);
			infoBox.setEffect(shadow);
			infoBox.setStyle("-fx-background-color: #f4f4f4 ; -fx-background-radius : 30 ");

			
			
			bPane.setCenter(infoBox);
			bPane.setBackground(new Background(myBI));	
			bPane.setPadding(new Insets(150,0,50,0));

			scene1 = new Scene(bPane, 600, 860);
			scene1.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

			radio1.setOnAction(e-> {
					if (radio1.isSelected()) {

						pane.getChildren().get(3).setVisible(true);
					}
				
			});
			radio2.setOnAction(e-> {
			
					if (radio2.isSelected()) {

						pane.getChildren().get(3).setVisible(false);

					}
			});
			
			button.setOnAction(e -> {
				verifyLogin vl = new verifyLogin(name,noId );
				if ((name.getText().isEmpty()||(noId.getText().isEmpty()))&&(!radio2.isSelected())||(name.getText().isEmpty())&&(radio2.isSelected()))
			      {
			    	  pane.getChildren().get(5).setVisible(true);
			      }else if(!vl.login() && radio1.isSelected()) {
			    	  pane.getChildren().get(5).setVisible(true);
			      }
				else if(vl.login() || radio2.isSelected()){
				window.setScene(secondInterface());
				}
			});
			}catch(Exception e) {

            }
		return scene1;

	}
	
	public Scene secondInterface() {
		
try {
			
			ImageView beef = new ImageView(new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 2\\Beefset Order.png")));
			ImageView chicken = new ImageView(new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 2\\Chickenset Order.png")));
			ImageView veggie = new ImageView(new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 2\\Veggieset Order.png")));
			ImageView beefSet = new ImageView(new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 2\\Beef Order.png")));
			ImageView chickenSet = new ImageView(new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 2\\Chicken Order.png")));
			ImageView veggieSet = new ImageView(new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 2\\Veggie Order.png")));
			ImageView itemTomato = new ImageView(new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 2\\Tomato.png")));
			ImageView itemCheese = new ImageView(new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 2\\Cheese.png")));
			ImageView itemEgg = new ImageView(new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 2\\Egg.png")));
			ImageView itemBeef = new ImageView(new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 2\\Beef.png")));
			ImageView itemChicken = new ImageView(new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 2\\Chicken.png")));
			ImageView itemVeggie = new ImageView(new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 2\\Veggie.png")));
			
			
			
			
			
			
			
			 Spinner<Integer> spinner1 = new Spinner<Integer>(0,100,0,1);
		      spinner1.setValueFactory( new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		    Spinner<Integer> spinner2 = new Spinner<Integer>(0,100,0,1);
		      spinner2.setValueFactory( new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		    Spinner<Integer> spinner3 = new Spinner<Integer>(0,100,0,1);
		      spinner3.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		    Spinner<Integer> spinner4 = new Spinner<Integer>(0,100,0,1);
		      spinner4.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		    Spinner<Integer> spinner5 = new Spinner<Integer>(0,100,0,1);
		      spinner5.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));  
		    Spinner<Integer> spinner6 = new Spinner<Integer>(0,100,0,1);
		      spinner6.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		    Spinner <Integer> Stomato = new Spinner<Integer>(0,100,0,1);
				Stomato.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
			Spinner <Integer> Slettuce = new Spinner<Integer>(0,100,0,1);
				Slettuce.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		    Spinner <Integer> Scheese = new Spinner<Integer>(0,100,0,1);
				Scheese.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
			Spinner <Integer> Segg = new Spinner<Integer>(0,100,0,1);
				Segg.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
			Spinner <Integer> SpattyBeef = new Spinner<Integer>(0,100,0,1);
				SpattyBeef.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
			Spinner <Integer> SpattyVeggie = new Spinner<Integer>(0,100,0,1);
				SpattyVeggie.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
			Spinner <Integer> SpattyChicken = new Spinner<Integer>(0,100,0,1);
				SpattyChicken.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
				
		      
			TextField total = new TextField();	
			
			
			TableView<BurgerMenu> list = new TableView<>();
		     
			 TableColumn<BurgerMenu,String> column1 =new TableColumn<>("Item");
		     column1.setCellValueFactory(new PropertyValueFactory<>("item"));

		      
		     TableColumn<BurgerMenu,Double> column2 = new TableColumn<>("Price(RM)");
		     column2.setCellValueFactory(new PropertyValueFactory<>("price"));
		      
		     TableColumn<BurgerMenu,Double> column3 = new TableColumn<>("Quantity");
		     column3.setCellValueFactory(new PropertyValueFactory<>("quantity"));
		      
		      list.setPrefSize(500, 900);
		      list.getColumns().add(column1);
		      list.getColumns().add(column2);
		      list.getColumns().add(column3);
		      list.setEditable(true);
		      
		      column1.prefWidthProperty().bind(list.widthProperty().multiply(0.3333333));
		      column2.prefWidthProperty().bind(list.widthProperty().multiply(0.3333333));
		      column3.prefWidthProperty().bind(list.widthProperty().multiply(0.333333));
		   
		      column1.setResizable(false);
		      column2.setResizable(false);
		      column3.setResizable(false);
		      list.setMaxHeight(200);
		      list.setPrefHeight(300);
		      list.setPrefWidth(200);
		      list.setPrefSize(300, 100);
		      

		      
		      spinner1.valueProperty().addListener(new ChangeListener<Integer>() {
			     
		           BurgerMenu beefset = new BurgerMenu("Beef Burger Set",13.00,0);
					@Override
					public void changed(ObservableValue<? extends Integer> arg0, Integer oldValue, Integer newValue) {
						
						double price;
						//newValue tu alam spinner dah
						if(newValue == 0) {
							list.getItems().remove(beefset);
							price = 13.00 * newValue;
							total.clear();
						}else if(newValue > oldValue) {
							if(list.getItems().contains(beefset)==true) {
								list.getItems().remove(beefset);
								price = 12.00 * newValue;
								beefset = new BurgerMenu("Beef Burger Set",price,newValue);
								list.getItems().add(beefset);
								total.clear();
								
							}else {
							price = 13.00 * newValue;
							beefset = new BurgerMenu("Beef Burger Set",price,newValue);
							list.getItems().add(beefset);
							total.clear();
							
							}
							
							
						}else if(newValue < oldValue) {
							list.getItems().remove(beefset);
							price = 13.00 * newValue;
							beefset = new BurgerMenu("Beef Burger Set",price,newValue);
							list.getItems().add(beefset);
							total.clear();
							
						}
						
					}
		        });
			
		      spinner2.valueProperty().addListener(new ChangeListener<Integer>() {
		    	  BurgerMenu chickenset = new BurgerMenu("Chicken Burger Set",13.00,0);
		           
					@Override
					public void changed(ObservableValue<? extends Integer> arg0, Integer oldValue, Integer newValue) {
						// TODO Auto-generated method stub
						double price1;
						if(newValue == 0) {
							list.getItems().remove(chickenset);
							price1 = 0;
							total.clear();
						}else if(newValue > oldValue) {
							if(list.getItems().contains(chickenset)==true) {
								list.getItems().remove(chickenset);
								price1 = 13.00 * newValue;
								chickenset = new BurgerMenu("Chicken Burger Set",price1,newValue);
								list.getItems().add(chickenset);
								total.clear();
								
							}else {
							price1 = 13.00 * newValue;
							chickenset = new BurgerMenu("Chicken Burger Set",price1,newValue);
							list.getItems().add(chickenset);
							total.clear();
							
							}
							
							
						}else if(newValue < oldValue) {
							list.getItems().remove(chickenset);
							price1 = 13.00 * newValue;
							chickenset = new BurgerMenu("Chicken Burger Set",price1,newValue);
							list.getItems().add(chickenset);
							total.clear();
							
						}
						
					}
					
		        });
		      
		      spinner3.valueProperty().addListener(new ChangeListener<Integer>() {
			    	 
		    	  BurgerMenu veggieset = new BurgerMenu("Veggie Burger Set",15.00,0); 
					@Override
					public void changed(ObservableValue<? extends Integer> arg0, Integer oldValue, Integer newValue) {
						// TODO Auto-generated method stub 
						double price2;
						if(newValue == 0) {
							list.getItems().remove(veggieset);
							price2 = 0;
							total.clear();
						}else if(newValue > oldValue) {
							if(list.getItems().contains(veggieset)==true) {
								list.getItems().remove(veggieset);
								price2 = 15.00 * newValue;
								veggieset = new BurgerMenu("Veggie Burger Set",price2,newValue);
								list.getItems().add(veggieset);
								total.clear();
								
							}else {
							price2 = 15.00 * newValue;
							veggieset = new BurgerMenu("Veggie Burger Set",price2,newValue);
							list.getItems().add(veggieset);
							total.clear();
							
							}
							
							
						}else if(newValue < oldValue) {
							list.getItems().remove(veggieset);
							price2 = 15.00 * newValue;
							veggieset = new BurgerMenu("Veggie Burger Set",price2,newValue);
							list.getItems().add(veggieset);
							total.clear();
							
						}
						
					}
		        });
			
		      
		      spinner4.valueProperty().addListener(new ChangeListener<Integer>() {
		    	  
		    	   BurgerMenu beef = new BurgerMenu("Beef Burger",9.00,0);
		           
					@Override
					public void changed(ObservableValue<? extends Integer> arg0, Integer oldValue, Integer newValue) {
						// TODO Auto-generated method stub
						double price3;
						
						if(newValue == 0) {
							list.getItems().remove(beef);
							price3 = 0;
							total.clear();
						}else if(newValue > oldValue) {
							if(list.getItems().contains(beef)==true) {
								list.getItems().remove(beef);
								price3 = 9.00 * newValue;
								beef = new BurgerMenu("Beef Burger",price3,newValue);
								list.getItems().add(beef);
								total.clear();
								
							}else {
							price3 = 9.00 * newValue;
							beef = new BurgerMenu("Beef Burger",price3,newValue);
							list.getItems().add(beef);
							total.clear();
							
							}
							
							
						}else if(newValue < oldValue) {
							list.getItems().remove(beef);
							price3 = 9.00 * newValue;
							beef = new BurgerMenu("Beef Burger",price3,newValue);
							list.getItems().add(beef);
							total.clear();
							
						}
						
					}
		        });
			
		      spinner5.valueProperty().addListener(new ChangeListener<Integer>() {
		    	  	
		            BurgerMenu chicken = new BurgerMenu("Chicken Burger",9.00,0);
					@Override
					public void changed(ObservableValue<? extends Integer> arg0, Integer oldValue, Integer newValue) {
						// TODO Auto-generated method stub
						double price4;
						if(newValue == 0) {
							list.getItems().remove(chicken);
							price4 = 0;
							total.clear();
						}else if(newValue > oldValue) {
							if(list.getItems().contains(chicken)==true) {
								list.getItems().remove(chicken);
								price4 = 9.00 * newValue;
								chicken = new BurgerMenu("Chicken Burger",price4,newValue);
								list.getItems().add(chicken);
								total.clear();
								
							}else {
							price4 = 9.00 * newValue;
							chicken = new BurgerMenu("Chicken Burger",price4,newValue);
							list.getItems().add(chicken);
							total.clear();
							
							}
							
							
						}else if(newValue < oldValue) {
							list.getItems().remove(chicken);
							price4 = 9.00 * newValue;
							chicken = new BurgerMenu("Chicken Burger",price4,newValue);
							list.getItems().add(chicken);
							total.clear();
							
						}
					}
		        });
		      
		      spinner6.valueProperty().addListener(new ChangeListener<Integer>() {
		    	  BurgerMenu veggie = new BurgerMenu("Veggie Burger",10.00,0);
					@Override
					public void changed(ObservableValue<? extends Integer> arg0, Integer oldValue, Integer newValue) {
						// TODO Auto-generated method stub
						double price5;
						if(newValue == 0) {
							list.getItems().remove(veggie);
							price5 = 0;
							total.clear();
						}else if(newValue > oldValue) {
							if(list.getItems().contains(veggie)==true) {
								list.getItems().remove(veggie);
								price5 = 10.00 * newValue;
								veggie = new BurgerMenu("Veggie Burger",price5,newValue);
								list.getItems().add(veggie);
								total.clear();
								
							}else {
							price5 = 10.00 * newValue;
							veggie = new BurgerMenu("Veggie Burger",price5,newValue);
							list.getItems().add(veggie);
							total.clear();
							
							}
							
							
						}else if(newValue < oldValue) {
							list.getItems().remove(veggie);
							price5 = 10.00 * newValue;
							veggie = new BurgerMenu("Veggie Burger",price5,newValue);
							list.getItems().add(veggie);
							total.clear();
						}
					}
		        });
		      
		      Stomato.valueProperty().addListener(new ChangeListener<Integer>() {
		    	  	
		    	  BurgerMenu tomato = new BurgerMenu("Tomato",0.50,0);
					@Override
					public void changed(ObservableValue<? extends Integer> arg0, Integer oldValue, Integer newValue) {
						// TODO Auto-generated method stub
						double price7;
						if(newValue == 0) {
							list.getItems().remove(tomato);
							price7 = 0.50 * newValue;
						}else if(newValue > oldValue) {
							if(list.getItems().contains(tomato)==true) {
								list.getItems().remove(tomato);
								price7 = 0.50 * newValue;
								tomato = new BurgerMenu("Tomato",price7,newValue);
								list.getItems().add(tomato);
								total.clear();
								
							}else {
							price7 = 0.50 * newValue;
							tomato = new BurgerMenu("Tomato",price7,newValue);
							list.getItems().add(tomato);
							total.clear();
							
							}
							
							
						}else if(newValue < oldValue) {
							list.getItems().remove(tomato);
							price7 = 0.50 * newValue;
							tomato = new BurgerMenu("Tomato",price7,newValue);
							list.getItems().add(tomato);
							total.clear();
							
						}
					}
		        });
		      
		      Slettuce.valueProperty().addListener(new ChangeListener<Integer>() {
		    	  BurgerMenu lettuce = new BurgerMenu("Lettuce",0.50,0);
					@Override
					public void changed(ObservableValue<? extends Integer> arg0, Integer oldValue, Integer newValue) {
						// TODO Auto-generated method stub
						double price8;
						if(newValue == 0) {
							list.getItems().remove(lettuce);
							price8 = 0.50 * newValue;
							total.clear();
						}else if(newValue > oldValue) {
							if(list.getItems().contains(lettuce)==true) {
								list.getItems().remove(lettuce);
								price8 = 0.50 * newValue;
								lettuce = new BurgerMenu("Lettuce",price8,newValue);
								list.getItems().add(lettuce);
								total.clear();
								
							}else {
							price8 = 0.50 * newValue;
							lettuce = new BurgerMenu("Lettuce",price8,newValue);
							list.getItems().add(lettuce);
							total.clear();
							
							}
							
							
						}else if(newValue < oldValue) {
							list.getItems().remove(lettuce);
							price8 = 0.50 * newValue;
							lettuce = new BurgerMenu("Lettuce",price8,newValue);
							list.getItems().add(lettuce);
							total.clear();
							
						}
					}
		        });;
		        
		        Scheese.valueProperty().addListener(new ChangeListener<Integer>() {
			    	  
			    	  BurgerMenu cheese = new BurgerMenu("Cheese",1.00,0);
						@Override
						public void changed(ObservableValue<? extends Integer> arg0, Integer oldValue, Integer newValue) {
						
							double price9;
							if(newValue == 0) {
								list.getItems().remove(cheese);
								price9 = 1.00 * newValue;
								total.clear();
							}else if(newValue > oldValue) {
								if(list.getItems().contains(cheese)==true) {
									list.getItems().remove(cheese);
									price9 = 1.00 * newValue;
									cheese = new BurgerMenu("Cheese",price9,newValue);
									list.getItems().add(cheese);
									total.clear();
									
								}else {
								price9 = 1.00 * newValue;
								cheese = new BurgerMenu("Cheese",price9,newValue);
								list.getItems().add(cheese);
								total.clear();
								
								}
								
								
							}else if(newValue < oldValue) {
								list.getItems().remove(cheese);
								price9 = 1.00 * newValue;
								cheese = new BurgerMenu("Cheese",price9,newValue);
								list.getItems().add(cheese);
								total.clear();
								
							}
						}
			        });
		        
		        Segg.valueProperty().addListener(new ChangeListener<Integer>() {
			    	  
			    	  BurgerMenu egg = new BurgerMenu("Egg",1.00,0);
						@Override
						public void changed(ObservableValue<? extends Integer> arg0, Integer oldValue, Integer newValue) {
							// TODO Auto-generated method stub
							double price10;
							if(newValue == 0) {
								list.getItems().remove(egg);
								price10 = 0;
								total.clear();
							}else if(newValue > oldValue) {
								if(list.getItems().contains(egg)==true) {
									list.getItems().remove(egg);
									price10 = 1.00 * newValue;
									egg = new BurgerMenu("Egg",price10,newValue);
									list.getItems().add(egg);
									total.clear();
									
								}else {
								price10 = 1.00 * newValue;
								egg = new BurgerMenu("Egg",price10,newValue);
								list.getItems().add(egg);
								total.clear();
								
								}
								
								
							}else if(newValue < oldValue) {
								list.getItems().remove(egg);
								price10 = 1.00 * newValue;
								egg = new BurgerMenu("Egg",price10,newValue);
								list.getItems().add(egg);
								total.clear();
								
							}
						}
			        });
		      
		        SpattyChicken.valueProperty().addListener(new ChangeListener<Integer>() {
		    	  	
			    	  BurgerMenu patty1 = new BurgerMenu("Chicken Patty",2.00,0);
			    	  	public void changed(ObservableValue<? extends Integer> arg0, Integer oldValue, Integer newValue) {
							// TODO Auto-generated method stub
							double price11;
							if(newValue == 0) {
								list.getItems().remove(patty1);
								price11 = 2.00 * newValue;
								//total.clear();
							}else if(newValue > oldValue) {
								if(list.getItems().contains(patty1)==true) {
									list.getItems().remove(patty1);
									price11 = 2.00 * newValue;
									patty1 = new BurgerMenu("Chicken Patty",price11,newValue);
									list.getItems().add(patty1);
									total.clear();
									
								}else {
								price11 = 2.00 * newValue;
								patty1 = new BurgerMenu("Chicken Patty",price11,newValue);
								list.getItems().add(patty1);
								total.clear();
								
								}
								
								
							}else if(newValue < oldValue) {
								list.getItems().remove(patty1);
								price11 = 2.00 * newValue;
								patty1 = new BurgerMenu("Chicken Patty",price11,newValue);
								list.getItems().add(patty1);
								total.clear();
								
							}
						}
			        });
		        
		        SpattyBeef.valueProperty().addListener(new ChangeListener<Integer>() {
		    	  	
			    	  BurgerMenu patty = new BurgerMenu("Beef Patty",2.00,0);
			    	  	public void changed(ObservableValue<? extends Integer> arg0, Integer oldValue, Integer newValue) {
							// TODO Auto-generated method stub
							double price6;
							if(newValue == 0) {
								list.getItems().remove(patty);
								price6 = 2.00 * newValue;
								total.clear();
							}else if(newValue > oldValue) {
								if(list.getItems().contains(patty)==true) {
									list.getItems().remove(patty);
									price6 = 2.00 * newValue;
									patty = new BurgerMenu("Beef Patty",price6,newValue);
									list.getItems().add(patty);
									total.clear();
									
								}else {
								price6 = 2.00 * newValue;
								patty = new BurgerMenu("Beef Patty",price6,newValue);
								list.getItems().add(patty);
								total.clear();
								
								}
								
								
							}else if(newValue < oldValue) {
								list.getItems().remove(patty);
								price6 = 2.00 * newValue;
								patty = new BurgerMenu("Beef Patty",price6,newValue);
								list.getItems().add(patty);
								total.clear();
								
							}
						}
			    	  	
			    	  	
			        });
		        
		        SpattyVeggie.valueProperty().addListener(new ChangeListener<Integer>() {
		    	  	
			    	  BurgerMenu patty2 = new BurgerMenu("Veggie Patty",3.00,0);
			    	  	public void changed(ObservableValue<? extends Integer> arg0, Integer oldValue, Integer newValue) {
							// TODO Auto-generated method stub
							double price12;
							if(newValue == 0) {
								list.getItems().remove(patty2);
								price12 = 3.00 * newValue;
								total.clear();
							}else if(newValue > oldValue) {
								if(list.getItems().contains(patty2)==true) {
									list.getItems().remove(patty2);
									price12 = 3.00 * newValue;
									patty2 = new BurgerMenu("Veggie Patty",price12,newValue);
									list.getItems().add(patty2);
									total.clear();
									
								}else {
								price12 = 3.00 * newValue;
								patty2 = new BurgerMenu("Veggie Patty",price12,newValue);
								list.getItems().add(patty2);
								total.clear();
								
								}
								
								
							}else if(newValue < oldValue) {
								list.getItems().remove(patty2);
								price12 = 3.00 * newValue;
								patty2 = new BurgerMenu("Beef Patty",price12,newValue);
								list.getItems().add(patty2);
								total.clear();
								
							}
						}
			        });
				
				
		    BorderPane Bpane = new BorderPane();
		
			
			//top
			HBox header = new HBox(5);
			Label order = new Label("ORDER");
			order.setStyle("-fx-text-fill: white; -fx-font-size: 20");
			header.setAlignment(Pos.TOP_CENTER);
			header.setStyle("-fx-background-color: linear-gradient(from 25% 25% to 100% 100%, #f2994a, #f6a761); -fx-background-radius: 0 0 18 18; -fx-border-radius: 0 0 18 18; ");
			header.setPadding(new Insets(15,0,15,0));
			header.getChildren().addAll(order);
			Bpane.setTop(header);
			
			
			//right
			 ScrollBar s = new ScrollBar();  
			 s.setOrientation(Orientation.VERTICAL);
			 s.setMin(0);
			 s.setPrefSize(5, 860);
			 
		     s.setMax(860);
		     s.setValue(75);
		     s.setOpacity(0.7);
		     s.adjustValue(50);
		     s.setUnitIncrement(50.0);//nak bagi laju bile scroll
		     s.setVisibleAmount(50);//ubah saiz bar

		     Bpane.setRight(s);
		     
		    
		    	 s.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
				     
			         Bpane.setLayoutY(-new_val.doubleValue());
				});
			
		
			//center
			Button ok = new Button("Add To Cart");
			ok.setMaxWidth(200);
		    
		    DropShadow shadow = new DropShadow();
			shadow.setRadius(15);
			shadow.setColor(Color.web("#e4e4e4"));
		    
			Label labelSet = new Label("SET");
			labelSet.setAlignment(Pos.CENTER);
			labelSet.setStyle("-fx-text-fill: #4d4d4d; -fx-font-size: 20");
			
			Label labelAla = new Label("ALA CARTE");
			labelSet.setAlignment(Pos.CENTER);
			labelSet.setStyle("-fx-text-fill: #4d4d4d; -fx-font-size: 20");
			
			Label labelAdd = new Label("CUSTOMIZE YOUR BURGER");
			labelSet.setAlignment(Pos.CENTER);
			labelSet.setStyle("-fx-text-fill: #4d4d4d; -fx-font-size: 20");
			
			HBox box1 = new HBox();
			box1.setAlignment(Pos.TOP_CENTER);
			box1.getChildren().addAll(spinner1);
			beef.setEffect(shadow);
			HBox box2 = new HBox();
			box2.setAlignment(Pos.TOP_CENTER);
			box2.getChildren().addAll(spinner2);
			chicken.setEffect(shadow);
			HBox box3 = new HBox();
			box3.setAlignment(Pos.TOP_CENTER);
			box3.getChildren().addAll(spinner3);
			veggie.setEffect(shadow);
			HBox box4 = new HBox();
			box4.setAlignment(Pos.TOP_CENTER);
			box4.getChildren().addAll(spinner4);
			beefSet.setEffect(shadow);
			HBox box5 = new HBox();
			box5.setAlignment(Pos.TOP_CENTER);
			box5.getChildren().addAll(spinner5);
			chickenSet.setEffect(shadow);
			HBox box6 = new HBox();
			box6.setAlignment(Pos.TOP_CENTER);
			box6.getChildren().addAll(spinner6);
			veggieSet.setEffect(shadow);
			VBox box = new VBox(10);
			box.setAlignment(Pos.TOP_CENTER);
			box.setPadding(new Insets(30,0,0,0));
			
			VBox addItem = new VBox(5);
			HBox layer1 = new HBox(5);
			
			VBox itemtomato = new VBox();
			itemtomato.getChildren().addAll(itemTomato,Stomato);
			Stomato.setMaxWidth(100);
			itemtomato.setAlignment(Pos.CENTER);
			
			VBox itemcheese = new VBox();
			itemcheese.getChildren().addAll(itemCheese,Scheese);
			Scheese.setMaxWidth(100);
			itemcheese.setAlignment(Pos.CENTER);
			
			VBox itemegg = new VBox();
			itemegg.getChildren().addAll(itemEgg,Segg);
			Segg.setMaxWidth(100);
			itemegg.setAlignment(Pos.CENTER);
			
			layer1.getChildren().addAll(itemtomato,itemcheese,itemegg);
			layer1.setAlignment(Pos.CENTER);
			
			HBox layer2 = new HBox(5);
			
			VBox itembeef = new VBox();
			itembeef.getChildren().addAll(itemBeef,SpattyBeef);
			SpattyBeef.setMaxWidth(100);
			itembeef.setAlignment(Pos.CENTER);
			
			VBox itemchicken = new VBox();
			itemchicken.getChildren().addAll(itemChicken,SpattyChicken);
			SpattyChicken.setMaxWidth(100);
			itemchicken.setAlignment(Pos.CENTER);
			
			VBox itemveggie = new VBox();
			itemveggie.getChildren().addAll(itemVeggie,SpattyVeggie);
			SpattyVeggie.setMaxWidth(100);
			itemveggie.setAlignment(Pos.CENTER);
			
			layer2.getChildren().addAll(itembeef,itemchicken,itemveggie);
			layer2.setAlignment(Pos.CENTER);
			
			addItem.getChildren().addAll(layer1,layer2);
			addItem.setPadding(new Insets(0,0,15,0));
			
			
			
			box.getChildren().addAll(labelSet,beef,box1,chicken,box2,veggie,box3,labelAla,beefSet,box4,chickenSet,box5,veggieSet,box6,labelAdd,addItem,ok);
			Bpane.setCenter(box);
						
			 ok.setOnAction(e->{
			    	window.setScene(thirdInterface(list,column1,column2,column3));
			      });
			
			
			scene2 = new Scene(Bpane,600,860);
			scene2.setFill(Color.web("#f4f4f4"));
			scene2.getStylesheets().add(getClass().getResource("application2.css").toExternalForm());
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return scene2;
	}
	
public Scene thirdInterface(TableView<BurgerMenu> list, TableColumn<BurgerMenu,String> column1, TableColumn<BurgerMenu,Double> column2, TableColumn<BurgerMenu,Double> column3) {
	  
	double subtotal= 0;
		try {

			BorderPane Bpane = new BorderPane();
			Bpane.setPadding(new Insets(0,0,15,0));
			
			//top
			
			HBox header = new HBox(210);
			header.setStyle("-fx-background-color: linear-gradient(from 25% 25% to 100% 100%, #f2994a, #f6a761); -fx-background-radius: 0 0 18 18; -fx-border-radius: 0 0 18 18");
		    Button back = new Button ("Back");
		    back.setAlignment(Pos.TOP_LEFT);
		    back.setStyle("-fx-background-color: transparent");
			Label headerName = new Label("Your Cart");
			headerName.setStyle("-fx-text-fill: white; -fx-font-size: 20");
			header.getChildren().addAll(back,headerName);
			Bpane.setTop(header);
			
			
			
			 //center
			TextField text = new TextField();
			text.setEditable(false);
			
			Label lblTotal = new Label("Sub total");
			
			HBox box1 = new HBox(10);
			box1.getChildren().addAll(lblTotal,text);
			box1.setAlignment(Pos.CENTER);
			
			VBox box2 = new VBox(10);
			
			list.setFixedCellSize(50);
		    list.prefHeightProperty().bind(list.fixedCellSizeProperty().multiply(Bindings.size(list.getItems()).add(1.01)));
		    list.minHeightProperty().bind(list.prefHeightProperty());
		    list.maxHeightProperty().bind(list.prefHeightProperty());
		    Label coupon = new Label("Coupon Code");
		    TextField coupon1 = new TextField();
			Button coupon2 = new Button("Enter");
			HBox listcoupon = new HBox(10);
			listcoupon.getChildren().addAll(coupon,coupon1,coupon2);
			listcoupon.setAlignment(Pos.CENTER);
			GridPane statepane = new GridPane();
			statepane.setAlignment(Pos.CENTER); 
		    statepane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		    statepane.setHgap(5.5);
		    statepane.setVgap(5.5);
			Label state = new Label("Coupon is valid and applied");
			Label state1 = new Label("Coupon invalid");
			statepane.add(state, 0, 1);
			statepane.add(state1, 0, 1);
			state1.setStyle("-fx-text-fill: red");
			box2.setAlignment(Pos.CENTER);
			box2.getChildren().addAll(list,box1,listcoupon,statepane);
			statepane.getChildren().get(0).setVisible(false);
			statepane.getChildren().get(1).setVisible(false);
			
			
			
			
			
			
				   
	 		for(int i = 0; i< list.getItems().size();i++) {
	 			
	 			subtotal += column2.getCellData(i);
	 		    	
	 		      }
	 		
	 		
	 			  String newtotal = Double.toString(subtotal);
	 		      text.setText(String.format("RM%.2f", subtotal));
	 		      
	 		     coupon2.setOnAction(new EventHandler<ActionEvent>(){
	 				
	 				
	 		    	   @Override
	 		    	   public void handle(ActionEvent event) {
	 		    		   
	 		    		   if(coupon1.getText().equals("20500")) {
	 		    			   double a = Double.parseDouble(newtotal) - 5;
	 		    			  text.setText(String.format("RM%.2f", a));
	 		    			 statepane.getChildren().get(0).setVisible(true);
	 		    			statepane.getChildren().get(1).setVisible(false);
	 		    		   }else {
	 		    				statepane.getChildren().get(1).setVisible(true);
	 		    		   }
	 		    		  
	 			    		
	 		    		   
	 		    	   } 
	 		       });

		
		    Bpane.setCenter(box2);
		      
		      
		      
		      //bottom
		      Button payment = new Button("Confirm Payment");
		      payment.setPadding(new Insets(5,50,5,50));
		      VBox Bbox = new VBox(10);
		      Bbox.setAlignment(Pos.CENTER);
		      Bbox.getChildren().addAll(payment);
		      Bpane.setBottom(Bbox);
		      Bpane.setPadding(new Insets(0,0,30,0));
		      	      
		      back.setOnAction(e->{
		    	  
		    	  window.setScene(scene2);
		      });
		      
		      payment.setOnAction(e->{
		    	  Random rnd = new Random();
		    	  int id = (int) (Math.random() * 1000);
		    	  char alpha = (char) ('A' + rnd.nextInt(26));
		    	  PrintFileResit receipt = new PrintFileResit(list, column1,column2,column3,radio1,radio2,id,coupon1.getText(),alpha);
		    	  PrintFileCustomer customer = new PrintFileCustomer(list, column1,column2,column3,radio1,radio2,id,coupon1.getText(),alpha);
		    	  receipt.printFileResit();
		    	  customer.printFileCustomer();
		    	  
		    	  window.setScene(fourthInterface(text));
		    });
			
			scene3= new Scene(Bpane,600,860);
			scene3.getStylesheets().add(getClass().getResource("application3.css").toExternalForm());
		}
		
		catch (Exception e) {
			
			e.printStackTrace();
		} 
		
		return scene3;
		
	}
	
	
	
public Scene fourthInterface(TextField text) {
	
	try {
		
		
		Label discount = new Label("20% discount is applied");
		discount.setPadding(new Insets(0,15,0,15));
		discount.setStyle("-fx-text-fill: white");
		discount.setVisible(false);
		
		Label sst = new Label("Tax incl.");
		sst.setPadding(new Insets(0,0,0,15));
		sst.setStyle("-fx-text-fill: white");
		
		  double total1= Double.parseDouble(text.getText().substring(2));         
	      if(radio1.isSelected() == true) {
	    	 text.setText("RM" + String.format("%.2f",
				      ((total1*0.8) + (total1 * 0.05))));
	    	 
	    	discount.setVisible(true);
	     
	      }else if(radio2.isSelected() == true) {
	    	 text.setText("RM" + String.format("%.2f",
				      total1 + (total1 * 0.05)));
	      }

		Image image = new Image(new FileInputStream(
				"C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 1\\Burger 1(without bg)2.png"));
		Image image1 = new Image(new FileInputStream(
				"C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 4 and Interface Payment\\Cash.png"));
		Image image2 = new Image(new FileInputStream(
				"C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 4 and Interface Payment\\Card.png"));
		Image image3 = new Image(new FileInputStream(
				"C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 4 and Interface Payment\\GrabPay.png"));
		Image image4 = new Image(new FileInputStream(
				"C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 4 and Interface Payment\\touchngo.png"));
		
		ImageView logoKedai = new ImageView(image);
		logoKedai.setFitWidth(60);
		logoKedai.setFitHeight(60);
		ImageView cash = new ImageView(image1);
		cash.setFitWidth(80);
		cash.setFitHeight(40);
		ImageView card = new ImageView(image2);
		card.setFitWidth(70);
		card.setFitHeight(40);
		ImageView gp = new ImageView(image3);
		gp.setFitWidth(80);
		gp.setFitHeight(70);
		ImageView tng = new ImageView(image4);
		tng.setFitWidth(70);
		tng.setFitHeight(70);
		
		logoKedai.setFitWidth(60);
		logoKedai.setFitHeight(60);
		
		
		BorderPane bpane = new BorderPane();
		
		//top
		VBox totalInfo = new VBox();
		
		Label check = new Label("CHECK OUT");
		check.setAlignment(Pos.TOP_CENTER);
		check.setStyle("-fx-font-size: 20; -fx-text-fill: white");
		check.setPadding(new Insets(10,15,0,15));

		Label total = new Label("TOTAL");
		total.setPadding(new Insets(0,15,0,15));
		total.setStyle("-fx-font-size: 20; -fx-text-fill: white");
		
		String s=text.getText();
		Label price = new Label(s);
		price.setPadding(new Insets(-40,15,0,15));
		price.setStyle("-fx-font-size: 90; -fx-text-fill: white");
		
		
		
		
		
		
		
		
		GridPane gPane = new GridPane();
		
		gPane.add(total, 0, 0);
		gPane.add(price, 0, 1);
		gPane.add(sst, 0, 2);
		gPane.add(discount, 1, 2);
		
		
		
		totalInfo.getChildren().addAll(check,gPane);
		totalInfo.setAlignment(Pos.TOP_CENTER);
		totalInfo.setStyle("-fx-background-color: linear-gradient(from 25% 25% to 100% 100%, #f2994a, #f6a761); -fx-background-radius: 0 0 18 18; -fx-border-radius: 0 0 18 18; ");

		bpane.setTop(totalInfo);
		
		//center
		VBox center = new VBox(25);
		center.setAlignment(Pos.TOP_CENTER);
		
		DropShadow shadow = new DropShadow();
		shadow.setRadius(15);
		shadow.setColor(Color.web("#e4e4e4"));;
		
		Label paymentmethod = new Label("Select your payment method");
		paymentmethod.setStyle("-fx-text-fill: #707070");
		paymentmethod.setAlignment(Pos.CENTER_LEFT);
		paymentmethod.setPadding(new Insets(80,15,20,0));
		
		HBox firstlayer = new HBox(25);
		firstlayer.setAlignment(Pos.CENTER);
		
		Button cashbt = new Button("Pay by Cash",cash);
		cashbt.setContentDisplay(ContentDisplay.TOP);
		cashbt.setPrefSize(200, 130);
		cashbt.setEffect(shadow);
		
		Button cardbt = new Button("Pay by Card",card);
		cardbt.setContentDisplay(ContentDisplay.TOP);
		cardbt.setPrefSize(200, 130);
		cardbt.setEffect(shadow);
		
		HBox secondlayer = new HBox(25);
		secondlayer.setAlignment(Pos.CENTER);
		
		Button gpbt = new Button("Pay by GrabPay",gp);
		gpbt.setContentDisplay(ContentDisplay.TOP);
		gpbt.setPrefSize(200, 130);
		gpbt.setEffect(shadow);
		
		Button tngbt = new Button("Pay by TouchnGo",tng);
		tngbt.setContentDisplay(ContentDisplay.TOP);
		tngbt.setPrefSize(200, 130);
		tngbt.setEffect(shadow);
		
		firstlayer.getChildren().addAll(cashbt,cardbt);
		secondlayer.getChildren().addAll(gpbt,tngbt);
		secondlayer.setPadding(new Insets(0,0,30,0));
		

		center.getChildren().addAll(paymentmethod,firstlayer,secondlayer);
		
		bpane.setCenter(center);
		
		VBox owned = new VBox();
		Label textowned = new Label("Pak Karim Burger Store Co.");
		textowned.setStyle("-fx-font-size: 10 ; -fx-text-fill: #9e9e9e");
		Label textowned2 = new Label("Lot 666 Pak Karim Burger Berjaya, Kerajaan Langit, Awan 22/7, Langit Selangor");
		textowned2.setStyle("-fx-font-size: 10 ; -fx-text-fill: #9e9e9e");
		Label textowned3 = new Label("Established Since 2021");
		textowned3.setStyle("-fx-font-size: 10 ; -fx-text-fill: #9e9e9e");
		owned.getChildren().addAll(textowned,textowned2,textowned3);
		owned.setAlignment(Pos.BOTTOM_CENTER);
		bpane.setBottom(owned);
		bpane.setPadding(new Insets(0,0,15,0));
		
		  
		
		
		
		cashbt.setOnAction(e ->{
			
		window.setScene(cashInterface());
				
		});
		cardbt.setOnAction(e ->{
	
		window.setScene(cardInterface());
				
		});
		gpbt.setOnAction(e ->{

		window.setScene(grabPayInterface());
	
		});
		tngbt.setOnAction(e ->{

		window.setScene(tngInterface());
	
		});
			
		
		scene4 = new Scene(bpane, 600, 860);
		scene4.getStylesheets().add(getClass().getResource("application4.css").toExternalForm());
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return scene4;
}
	public Scene cashInterface() {
	
		try {
	
			BackgroundImage myBI = new BackgroundImage(
			new Image(new FileInputStream(
					"C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 1\\Background.jpg")),
			BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT,
			BackgroundSize.DEFAULT);
	
			Image image = new Image(new FileInputStream(
			"C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 4 and Interface Payment\\Cashier.png"));
	
			BorderPane bPane = new BorderPane();
	
			Label instruction = new Label("Please pay at the cashier");
		instruction.setStyle("-fx-font-size: 24");
	
		ImageView cashier = new ImageView(image);
		cashier.setFitWidth(200);
		cashier.setFitHeight(200);
	
		Button endOrder = new Button("END ORDER");
		endOrder.setMaxWidth(200);
	
		VBox cash = new VBox(80);
		cash.setAlignment(Pos.CENTER);
		cash.getChildren().addAll(instruction,cashier,endOrder);

	

		bPane.setCenter(cash);
		bPane.setBackground(new Background(myBI));	
		bPane.setPadding(new Insets(30,0,50,0));

		scene5 = new Scene(bPane, 600, 860);
		scene5.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

	
		endOrder.setOnAction(e -> {

			window.setScene(scene1);

		});}
		catch(Exception e) {
		
	}
		return scene5;

}
	public Scene cardInterface() {
		
		try {
	
			BackgroundImage myBI = new BackgroundImage(
			new Image(new FileInputStream(
					"C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 1\\Background.jpg")),
			BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT,
			BackgroundSize.DEFAULT);
	
			Image image = new Image(new FileInputStream(
			"C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 4 and Interface Payment\\Card Icon.png"));
	
			BorderPane bPane = new BorderPane();
	
			Label instruction = new Label("Please pay by wave or pin");
		instruction.setStyle("-fx-font-size: 24");
	
		ImageView cashier = new ImageView(image);
		cashier.setFitWidth(200);
		cashier.setFitHeight(200);
	
		Button endOrder = new Button("END ORDER");
		endOrder.setMaxWidth(200);
	
		VBox cash = new VBox(80);
		cash.setAlignment(Pos.CENTER);
		cash.getChildren().addAll(instruction,cashier,endOrder);

	

		bPane.setCenter(cash);
		bPane.setBackground(new Background(myBI));	
		bPane.setPadding(new Insets(30,0,50,0));

		scene6 = new Scene(bPane, 600, 860);
		scene6.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

	
		endOrder.setOnAction(e -> {

			window.setScene(scene1);

		});}
		catch(Exception e) {
		
	}
		return scene6;

}
	public Scene grabPayInterface() {
	
		try {
		
		BackgroundImage myBI = new BackgroundImage(
				new Image(new FileInputStream(
						"C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 1\\Background.jpg")),
				BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT,
				BackgroundSize.DEFAULT);
		
		Image image = new Image(new FileInputStream(
				"C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 4 and Interface Payment\\GrabPay QR.png"));
		
		BorderPane bPane = new BorderPane();
		
		Label instruction = new Label("Please scan the QR code below");
		instruction.setStyle("-fx-font-size: 24");
		
		ImageView grabicon = new ImageView(image);
		grabicon.setFitWidth(200);
		grabicon.setFitHeight(200);
		
		Button endOrder = new Button("END ORDER");
		endOrder.setMaxWidth(200);
		
		VBox grab = new VBox(80);
		grab.setAlignment(Pos.CENTER);
		grab.getChildren().addAll(instruction,grabicon,endOrder);

		

		bPane.setCenter(grab);
		bPane.setBackground(new Background(myBI));	
		bPane.setPadding(new Insets(30,0,50,0));

		scene7 = new Scene(bPane, 600, 860);
		scene7.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

		
		endOrder.setOnAction(e -> {

			window.setScene(scene1);

		});}
		catch(Exception e) {
			
		}
	return scene7;

}
	public Scene tngInterface() {
		
		try {
	
			BackgroundImage myBI = new BackgroundImage(
			new Image(new FileInputStream(
					"C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 1\\Background.jpg")),
			BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT,
			BackgroundSize.DEFAULT);
	
			Image image = new Image(new FileInputStream(
			"C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Interface 4 and Interface Payment\\Tng Icon.png"));
	
			BorderPane bPane = new BorderPane();
	
			Label instruction = new Label("Please scan the QR code below");
			instruction.setStyle("-fx-font-size: 24");
	
			ImageView cashier = new ImageView(image);
			cashier.setFitWidth(200);
			cashier.setFitHeight(200);
	
			Button endOrder = new Button("END ORDER");
			endOrder.setMaxWidth(200);
	
			VBox cash = new VBox(80);
			cash.setAlignment(Pos.CENTER);
			cash.getChildren().addAll(instruction,cashier,endOrder);
		
	

			bPane.setCenter(cash);
			bPane.setBackground(new Background(myBI));	
			bPane.setPadding(new Insets(30,0,50,0));

			scene8 = new Scene(bPane, 600, 860);
			scene8.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

	
			endOrder.setOnAction(e -> {

				window.setScene(scene1);

			});}
		catch(Exception e) {
		
	}
		return scene8;

}
	public static void main(String[] args) {
		launch(args);
	}
}
