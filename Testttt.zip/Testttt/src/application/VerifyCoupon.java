package application;

import java.io.File;
import java.util.Scanner;

import javafx.scene.control.TextField;

public class VerifyCoupon {
	private static Scanner x;
	private  TextField coupon;

	
	VerifyCoupon( TextField coupon){
		this.coupon=coupon;
	}
	
	public boolean login () {
		
		String input = coupon.getText();
		String filepath = "C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\coupon.txt";
		
		boolean found = false;
		String tempCoupon = "";
		
		try {
			
			x = new Scanner (new File (filepath));
			x.useDelimiter("[,\n]");
			
			while(x.hasNext() && !found){
				tempCoupon = x.next();
				
				if(tempCoupon.trim().equals(input.trim())){
							found = true;
						}
			}
			
			x.close();
			
		}
		
		catch(Exception e) 
		{

			e.printStackTrace();
		}
		return found;
	}

}
