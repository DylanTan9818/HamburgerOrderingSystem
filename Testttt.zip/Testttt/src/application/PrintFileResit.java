package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class PrintFileResit {
	
	private TableView<BurgerMenu> list;
	private TableColumn<BurgerMenu,String> column1;
	private TableColumn<BurgerMenu,Double> column2;
	private TableColumn<BurgerMenu,Double> column3;
	private RadioButton radio1;
	private RadioButton radio2;
	private int id;
	private String coupon;
	private char alpha;
	
	PrintFileResit(TableView<BurgerMenu> list,TableColumn<BurgerMenu,String> column1 ,TableColumn<BurgerMenu,Double> column2,TableColumn<BurgerMenu,Double> column3,RadioButton radio1,RadioButton radio2,int id,String coupon,char alpha){
		this.list=list;
		this.column1=column1;
		this.column2=column2;
		this.column3=column3;
		this.radio1=radio1;
		this.radio2=radio2;
		this.id = id;
		this.coupon = coupon;
		this.alpha = alpha;
		
	}

	public TableColumn<BurgerMenu, String> getColumn1() {
		return column1;
	}

	public TableColumn<BurgerMenu, Double> getColumn2() {
		return column2;
	}

	public TableColumn<BurgerMenu, Double> getColumn3() {
		return column3;
	}

	public TableView<BurgerMenu> getList() {
		return list;
	}
	
	public void printFileResit() {
		
		try {
						
			File resit = new File("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Customer and Order List.txt");
			
		      
		     double subtotal=0;
		     double total=0;
			 for(int i = 0; i< list.getItems().size();i++) {
	 		    	subtotal += column2.getCellData(i);
	 		    }
			 if(radio1.isSelected() == true) {
		    	 total=(subtotal*0.8)+(subtotal*0.05);
		    	 if(coupon.equals("20500")) {
	    			   total = total - 5;
	    		   }
		      }else if(radio2.isSelected() == true) {
		    	  total=subtotal+(subtotal*0.05);
		    	  if(coupon.equals("20500")) {
	    			   total = total - 5;
	    		   }
		      }
			
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();
			//System.out.println(dateFormat.format(date));
			PrintWriter output = new PrintWriter(new FileWriter(resit,true));
			Random rnd = new Random();
			output.println("********************Receipt********************\n");
			output.println("\t\t\t\tOrder Id : "+ (id)+ alpha+"\n");

			output.println("===============================================");
			output.printf("%-25s%-13s%-10s\n","Item","Qty","Price");
			output.println("===============================================");
			for(int i =0 ; i< list.getItems().size();i++) {
				output.printf("%-26s%-12sRM%-10s\n",column1.getCellData(i),column3.getCellData(i),String.format("%.2f",column2.getCellData(i)));
			}
			if(radio1.isSelected()) {
				
				if(coupon.equals("20500")) {
					output.println("-----------------------------------------------");
					output.printf("%-38sRM%-10.2f\n","Sub-total",subtotal);
					output.printf("\t%-34sRM%-10.2f\n","+Tax(sst)",subtotal*0.05);
					output.printf("\t%-34sRM%-10.2f\n","-Discount(20%)",subtotal*0.2);
					output.printf("\t%-34sRM%-10.2f\n","-Coupon",5.00);
					output.println("-----------------------------------------------");
					output.printf("%-38sRM%-10.2f\n","Total",total);
				}else {
				output.println("-----------------------------------------------");
				output.printf("%-38sRM%-10.2f\n","Sub-total",subtotal);
				output.printf("\t%-34sRM%-10.2f\n","+Tax(sst)",subtotal*0.05);
				output.printf("\t%-34sRM%-10.2f\n","-Discount(20%)",subtotal*0.2);
				output.println("-----------------------------------------------");
				output.printf("%-38sRM%-10.2f\n","Total",total);
				
				}
				}if(radio2.isSelected()) {
					
					
					if(coupon.equals("20500")) {
						output.println("-----------------------------------------------");
						output.printf("%-38sRM%-10.2f\n","Sub-total",subtotal);
						output.printf("\t%-34sRM%-10.2f\n","+Tax(sst)",subtotal*0.05);
						output.printf("\t%-34sRM%-10.2f\n","-Coupon",5.00);
						output.println("-----------------------------------------------");
						output.printf("%-38sRM%-10.2f\n","Total",total);
					}else {
						output.println("-----------------------------------------------");
						output.printf("%-38sRM%-10.2f\n","Sub-total",subtotal);
						output.printf("\t%-34sRM%-10.2f\n","+Tax(sst)",subtotal*0.05);
						output.println("-----------------------------------------------");
						output.printf("%-38sRM%-10.2f\n","Total",total);
					}
				}
			output.println("-----------------------------------------------");
			output.println("\t\t\tDate :" + dateFormat.format(date));
			output.println("-----------------------------------------------");

			output.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(IOException e) {
			
			e.printStackTrace();
		}
		
	}
	
		
		
		
	}