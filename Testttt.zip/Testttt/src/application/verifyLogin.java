package application;


import java.io.File;
import java.util.Scanner;
import javafx.scene.control.TextField;
public class verifyLogin {
	
	private static Scanner x;
	private  TextField name;
	private  TextField id;
	
	verifyLogin( TextField name,TextField id){
		this.id=id;
		this.name=name;
	}
	
	public boolean login () {
		
		String username = name.getText();
		String noid = id.getText();
		String filepath = "C:\\Users\\DylanTan9818\\eclipse-workspace\\Testttt\\src\\application\\Member.txt";
		
		boolean found = false;
		String tempUsername = "";
		String tempId = "";
		
		try 
		{
			x = new Scanner (new File (filepath));
			x.useDelimiter("[,\n]");
			
			while(x.hasNext() && !found)
			{
				tempUsername = x.next();
				tempId = x.next();
				
				if(tempUsername.trim().equals(username.trim()) && tempId.trim().equals(noid.trim()))
						{
							found = true;
						}
			}
			x.close();
			System.out.println(found);
			
		}
		
		catch(Exception e) 
		{
//			System.out.println("Member's information does not exist");
			e.printStackTrace();
		}
		return found;
	}

}