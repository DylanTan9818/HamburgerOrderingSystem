package application;

public class BurgerMenu {
	private String item = null;
	private double price = 0;
	private int quantity = 0;
	
	public BurgerMenu(String item, double price,int quantity) {
		this.item = item;
		this.price = price;
		this.setQuantity(quantity);
		}
	
	 
	   public void setItem(String item){
		   this.item = item;
		   }
	   public String getItem(){
		   return this.item;  
		   }
	  
	   public void setPrice(double price){
		   this.price = price;
		   }
	   public double getPrice(){
		   return this.price; 
		   }


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	
	}
	