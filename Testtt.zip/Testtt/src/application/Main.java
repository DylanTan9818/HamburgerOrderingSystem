package application;
	


import java.io.FileInputStream;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.*;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.control.*;



public class Main extends Application  {
	Stage window;
	Scene scene2, scene3;
	@Override
	public void start(Stage primaryStage) {
		window = primaryStage;
		
		try {
			  
			Image image = new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testtt\\Image\\Burger 1.png"));
			Image image1 = new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testtt\\Image\\Beef Set 1.png"));
			Image image2 = new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testtt\\Image\\Chicken Set 1.png"));
			Image image3 = new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testtt\\Image\\Veggie Set 1.png"));
			Image image4 = new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testtt\\Image\\Beef.png"));
			Image image5 = new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testtt\\Image\\Chicken.png"));
			Image image6 = new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testtt\\Image\\Veggie Patty.png"));
			
			BackgroundImage myBI= new BackgroundImage(new Image(new FileInputStream("C:\\Users\\DylanTan9818\\eclipse-workspace\\Testtt\\Image\\Cover1.jpg")),
			        BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
			          BackgroundSize.DEFAULT);
			//then you set to your node
			
		         
			
			
			  int width = (int)image.getWidth(); 
		      int height = (int)image.getHeight();
		      int width1 = (int)image1.getWidth(); 
		      int height1 = (int)image1.getHeight();
		      int width2 = (int)image2.getWidth(); 
		      int height2 = (int)image2.getHeight();
		      int width3 = (int)image3.getWidth(); 
		      int height3 = (int)image3.getHeight();
		      int width4 = (int)image4.getWidth(); 
		      int height4 = (int)image4.getHeight();
		      int width5 = (int) image5.getWidth();
		      int height5 = (int) image5.getHeight();
		      int width6 = (int) image6.getWidth();
		      int height6 = (int) image6.getHeight();
		      
		         
		      //Creating a writable image 
		      WritableImage wImage = new WritableImage(width, height); 
		      WritableImage wImage1 = new WritableImage(width1, height1);
		      WritableImage wImage2 = new WritableImage(width2, height2);
		      WritableImage wImage3 = new WritableImage(width3, height3);
		      WritableImage wImage4 = new WritableImage(width4, height4);
		      WritableImage wImage5 = new WritableImage(width5, height5);
		      WritableImage wImage6 = new WritableImage(width6, height6);
		         
		      //Reading color from the loaded image 
		      PixelReader pixelReader = image.getPixelReader();
		      PixelReader pixelReader1 = image1.getPixelReader();
		      PixelReader pixelReader2 = image2.getPixelReader();
		      PixelReader pixelReader3 = image3.getPixelReader();
		      PixelReader pixelReader4 = image4.getPixelReader();
		      PixelReader pixelReader5 = image5.getPixelReader();
		      PixelReader pixelReader6 = image6.getPixelReader();
		      
		      //getting the pixel writer 
		      PixelWriter writer = wImage.getPixelWriter();
		      PixelWriter writer1 = wImage1.getPixelWriter();
		      PixelWriter writer2 = wImage2.getPixelWriter();
		      PixelWriter writer3 = wImage3.getPixelWriter();
		      PixelWriter writer4 = wImage4.getPixelWriter();
		      PixelWriter writer5 = wImage5.getPixelWriter();
		      PixelWriter writer6 = wImage6.getPixelWriter();
		      
		      
		      //Reading the color of the image 
		      for(int y = 0; y < height; y++) { 
		         for(int x = 0; x < width; x++) { 
		            //Retrieving the color of the pixel of the loaded image   
		            Color color = pixelReader.getColor(x, y);
		           
		              
		            //Setting the color to the writable image 
		            writer.setColor(x, y, color.darker());
		          
		         }
		      }	
		      
		      for(int y = 0; y < height1; y++) { 
			         for(int x = 0; x < width1; x++) { 
			            //Retrieving the color of the pixel of the loaded image   
			            
			            Color color1 = pixelReader1.getColor(x, y);
			              
			            //Setting the color to the writable image 
			           
			            writer1.setColor(x, y, color1.darker());
			         }
			      }	
		      
		      for(int y = 0; y < height2; y++) { 
			         for(int x = 0; x < width2; x++) { 
			            //Retrieving the color of the pixel of the loaded image   
			            
			            Color color2 = pixelReader2.getColor(x, y);
			              
			            //Setting the color to the writable image 
			           
			            writer2.setColor(x, y, color2.darker());
			         }
			      }
		      for(int y = 0; y < height3; y++) { 
			         for(int x = 0; x < width3; x++) { 
			            //Retrieving the color of the pixel of the loaded image   
			            
			            Color color3 = pixelReader3.getColor(x, y);
			              
			            //Setting the color to the writable image 
			           
			            writer3.setColor(x, y, color3.darker());
			         }
			      }
		      
		      for(int y = 0; y < height4; y++) { 
			         for(int x = 0; x < width4; x++) { 
			            //Retrieving the color of the pixel of the loaded image   
			            
			            Color color4 = pixelReader4.getColor(x, y);
			              
			            //Setting the color to the writable image 
			           
			            writer4.setColor(x, y, color4.darker());
			         }
			      }	
		      
		      for(int y = 0; y < height4; y++) { 
			         for(int x = 0; x < width4; x++) { 
			            //Retrieving the color of the pixel of the loaded image   
			            
			            Color color4 = pixelReader4.getColor(x, y);
			              
			            //Setting the color to the writable image 
			           
			            writer4.setColor(x, y, color4.darker());
			         }
			      }	
		      
		      for(int y = 0; y < height5; y++) { 
			         for(int x = 0; x < width5; x++) { 
			            //Retrieving the color of the pixel of the loaded image   
			            
			            Color color5 = pixelReader5.getColor(x, y);
			              
			            //Setting the color to the writable image 
			           
			            writer5.setColor(x, y, color5.darker());
			         }
			      }	
		      
		      for(int y = 0; y < height6; y++) { 
			         for(int x = 0; x < width6; x++) { 
			            //Retrieving the color of the pixel of the loaded image   
			            
			            Color color6 = pixelReader6.getColor(x, y);
			              
			            //Setting the color to the writable image 
			           
			            writer6.setColor(x, y, color6.darker());
			         }
			      }	
		      //Setting the view for the writable image 
		      ImageView imageView = new ImageView(wImage); 
		      imageView.setFitHeight(200);
		      imageView.setFitWidth(200);
		      ImageView imageView1 = new ImageView(wImage1); 
		      imageView1.setFitHeight(150);
		      imageView1.setFitWidth(150);
		      ImageView imageView2 = new ImageView(wImage2); 
		      imageView2.setFitHeight(150);
		      imageView2.setFitWidth(150);
		      ImageView imageView3 = new ImageView(wImage3); 
		      imageView3.setFitHeight(150);
		      imageView3.setFitWidth(150);
		      ImageView imageView4 = new ImageView(wImage4); 
		      imageView4.setFitHeight(140);
		      imageView4.setFitWidth(140);
		      ImageView imageView5 = new ImageView(wImage5); 
		      imageView5.setFitHeight(140);
		      imageView5.setFitWidth(140);
		      ImageView imageView6 = new ImageView(wImage6); 
		      imageView6.setFitHeight(140);
		      imageView6.setFitWidth(140);
		      Label label1 =  new Label("Name:");
		      label1.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      Label label2 =  new Label("Member Validity:");
		      label2.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      Label label3 = new Label("Member ID:");
		      label3.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      Label label4 = new Label(" Beef Set");
		      label4.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      Label label5 = new Label("Chicken Set");
		      label5.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      Label label6 = new Label("Veggie Set");
		      label6.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      Label label7 = new Label("Beef ");
		      label7.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      Label label8 = new Label("Chicken ");
		      label8.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      Label label9 = new Label("Veggie ");
		      label9.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      Label label10 = new Label("Do you want to add items? ");
		      label10.setStyle("-fx-font-weight: bold; -fx-text-fill: white;-fx-font-size: 11.5");
		      Label label11 = new Label("Add On Items: ");
		      label11.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      Label label12 = new Label("Patty");
		      label12.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      Label label13 = new Label("   Tomato");
		      label13.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      Label label14 = new Label("   Lettuce ");
		      label14.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      Label label15 = new Label("   Cheese ");
		      label15.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      Label label16 = new Label("   Egg ");
		      label16.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      
		      
		              
		      //Creating a Group object  
		        
		            
		      GridPane pane = new GridPane(); 
		      pane.setAlignment(Pos.CENTER); 
		      pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		      pane.setHgap(5.5);
		      pane.setVgap(5.5);
		      
		       // Place nodes in the pane
		      RadioButton radio1 = new RadioButton("Yes  ");
		      radio1.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      RadioButton radio2 = new RadioButton("No");
		      radio2.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
		      RadioButton radio3 = new RadioButton("Yes  ");
		      radio3.setStyle("-fx-font-weight: bold; -fx-text-fill: white;-fx-font-size: 11.5");
		      RadioButton radio4 = new RadioButton("No");
		      radio4.setStyle("-fx-font-weight: bold; -fx-text-fill: white;-fx-font-size: 11.5");
		      ToggleGroup radioGroup = new ToggleGroup();
		      ToggleGroup radioGroup1 = new ToggleGroup();
		    
		      radio1.setToggleGroup(radioGroup);
		      radio2.setToggleGroup(radioGroup);
		      radio3.setToggleGroup(radioGroup1);
		      radio4.setToggleGroup(radioGroup1);
		      
		       pane.add(imageView,1,1);
		       pane.add(label1, 0, 2); 
		       pane.add(new TextField(), 1, 2);
		       pane.add(label2, 0, 3);
		       pane.add(new HBox(radio1,radio2), 1, 3);
		       pane.add(label3, 0, 4); 
			   pane.add(new TextField(), 1, 4);
			   pane.getChildren().get(5).setVisible(false);
    		   pane.getChildren().get(6).setVisible(false);
		       radio1.setOnAction(new EventHandler<ActionEvent>() {
		    	   @Override
		    	   public void handle(ActionEvent event) {
		    		   if(radio1.isSelected() == true) {
		    			   pane.getChildren().get(5).setVisible(true);
			    		   pane.getChildren().get(6).setVisible(true);
		    		   } 
		    	   }
		       });
		       radio2.setOnAction(new EventHandler<ActionEvent>(){
		    	   @Override
		    	   public void handle(ActionEvent event) {
		    		   if(radio2.isSelected() == true) {
		    			   pane.getChildren().get(5).setVisible(false);
		    			   pane.getChildren().get(6).setVisible(false);
		    			   
			    		
		    		   }  
		    	   }
		       });
		       BorderPane rootPane = new BorderPane();
		       
			   
		      
		       
		      Button button = new Button("Start Order");
		      button.setStyle("-fx-font-weight: bold");
		      pane.add(button, 1, 5); 
		      GridPane.setHalignment(button, HPos.CENTER);
		      Scene scene = new Scene(pane,400,400);
		      Button button2 = new Button("Payment");
		      button2.setStyle("-fx-font-weight: bold");
		      GridPane pane1 = new GridPane(); 
		      pane1.setAlignment(Pos.TOP_LEFT); 
		      pane1.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		      pane1.setHgap(5.5);
		      pane1.setVgap(5.5);
		      Spinner<Integer> spinner = new Spinner<Integer>(0,0,100,1);
		      spinner.setValueFactory(
		              new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		      Spinner<Integer> spinner1 = new Spinner<Integer>(0,0,100,1);
		      spinner1.setValueFactory(
		              new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		      Spinner<Integer> spinner2 = new Spinner<Integer>(0,0,100,1);
		      spinner2.setValueFactory(
		              new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		      Spinner<Integer> spinner3 = new Spinner<Integer>(0,0,100,1);
		      spinner3.setValueFactory(
		              new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		      Spinner<Integer> spinner4 = new Spinner<Integer>(0,0,100,1);
		      spinner4.setValueFactory(
		              new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		      Spinner<Integer> spinner5 = new Spinner<Integer>(0,0,100,1);
		      spinner5.setValueFactory(
		              new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		      Spinner<Integer> spinner6 = new Spinner<Integer>(0,0,100,1);
		      spinner6.setValueFactory(
		              new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		      Spinner<Integer> spinner7 = new Spinner<Integer>(0,0,100,1);
		      spinner7.setValueFactory(
		              new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		      Spinner<Integer> spinner8 = new Spinner<Integer>(0,0,100,1);
		      spinner8.setValueFactory(
		              new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		      Spinner<Integer> spinner9 = new Spinner<Integer>(0,0,100,1);
		      spinner9.setValueFactory(
		              new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		      Spinner<Integer> spinner10 = new Spinner<Integer>(0,0,100,1);
		      spinner10.setValueFactory(
		              new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
		      ListView list = new ListView();
		      list.setPrefHeight(320);
		      list.setPrefWidth(1000);
		 
		      
		      
		      pane1.add(imageView1, 0, 0);       
		      pane1.add(label4, 1,0);   
		      pane1.add(spinner, 2, 0); 
		      pane1.add(imageView2, 3,0);
		      pane1.add(label5, 4,0);
		      pane1.add(spinner1, 5,0);
		      pane1.add(imageView3, 6,0);
		      pane1.add(label6, 7, 0); 
			  pane1.add(spinner2, 8, 0);
			  pane1.add(imageView4, 0, 1);
			  pane1.add(label7, 1, 1);   
		      pane1.add(spinner3, 2,1);
		      pane1.add(imageView5, 3, 1);
		      pane1.add(label8, 4, 1);
		      pane1.add(spinner4, 5, 1);
		      pane1.add(imageView6, 6, 1);
		      pane1.add(label9, 7, 1); 
			  pane1.add(spinner5, 8, 1);
			  pane1.add(label10, 0, 8);
		      pane1.add(new HBox(radio3,radio4), 1, 8);
		      pane1.add(label11,0, 9);
			  pane1.add(label12, 0, 10);
			  pane1.add(spinner6, 1, 10);
			  pane1.add(label13, 2, 10);
			  pane1.add(spinner7, 3, 10);
			  pane1.add(label14, 4, 10);
			  pane1.add(spinner8, 5, 10);
			  pane1.add(label15, 6, 10);
			  pane1.add(spinner9, 7, 10);
			  pane1.add(label16, 8, 10);
			  pane1.add(spinner10, 9, 10);
			  
		      
		      GridPane addpane = new GridPane();
		       addpane.setAlignment(Pos.TOP_CENTER); 
			   addpane.setPadding(new Insets(10, 10, 10, 10));
			   addpane.setHgap(5);
			   addpane.setVgap(5);
			   TextField total = new TextField();
			   addpane.add(list,0,0);

			      GridPane addpane1 = new GridPane();
			       addpane1.setAlignment(Pos.TOP_CENTER); 
				   addpane1.setPadding(new Insets(10, 10, 10, 10));
				   addpane1.setHgap(5);
				   addpane1.setVgap(5);
			   Label labeltotal = new Label("Total:");
			   labeltotal.setStyle("-fx-font-weight: bold; -fx-text-fill: white");
			   addpane1.add(labeltotal, 0, 0);
			   addpane1.add(total, 1,0);
		      addpane1.add(button2, 2,0);
		      rootPane.setTop(pane1);
		      rootPane.setCenter(addpane);
		      rootPane.setBottom(addpane1);
//		       
		       
		      for(int i = 20; i < 31; i++) {
		      pane1.getChildren().get(i).setVisible(false);
		      }
		      
		      radio3.setOnAction(new EventHandler<ActionEvent>(){
		    	   @Override
		    	   public void handle(ActionEvent event) {
		    		   if(radio3.isSelected() == true) {
		    			   for(int i = 20; i < 31; i++) {
		    				      pane1.getChildren().get(i).setVisible(true);
		    				      }
			    		
		    		   }  
		    	   }
		       });
		      
		      radio4.setOnAction(new EventHandler<ActionEvent>(){
		    	   @Override
		    	   public void handle(ActionEvent event) {
		    		   if(radio4.isSelected() == true) {
		    			   for(int i = 20; i < 31; i++) {
		    				      pane1.getChildren().get(i).setVisible(false);
		    				      }
			    		
		    		   }  
		    	   }
		       });
		      
		     
		      
		      Scene scene2 = new Scene(rootPane);
		      GridPane pane2 = new GridPane(); 
		      pane2.setAlignment(Pos.CENTER); 
		      pane2.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		      pane2.setHgap(5.5);
		      pane2.setVgap(5.5);
		      Text end = new Text("Thank you for ordering. Please come again.");
		      end.setFill(Color.WHITE);
		      end.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
		      pane2.add(end, 0, 0);
		      Scene scene3 = new Scene(pane2,600,600);
		       button.setOnAction(e -> window.setScene(scene2));
		       // Create a scene and place it in the stage
		       button2.setOnAction(e -> window.setScene(scene3));
		          
			window.setTitle("PAK KARIM HAMBURGER STORE");
			pane.setBackground(new Background(myBI));
			rootPane.setBackground(new Background(myBI));
			pane2.setBackground(new Background(myBI));
		   
		    			
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			window.setScene(scene);
			window.getIcons().add(image);
			window.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}


}
